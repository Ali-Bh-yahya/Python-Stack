from User import User

class Student(User):
   def __init__(self, grade )